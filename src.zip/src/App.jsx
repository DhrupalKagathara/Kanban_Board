import React from "react";
import KanbanBoard from "./components/KanbanBoard";

function App() {
  return <KanbanBoard />;
}

export default App;
